function printNumbers(nums) {
    let num = Number(nums[0]);

    for(let i = num; i >= 1; i--)
        console.log(i);
}