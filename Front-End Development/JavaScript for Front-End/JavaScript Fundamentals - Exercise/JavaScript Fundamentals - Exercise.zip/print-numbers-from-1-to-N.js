function printNumbers(nums) {
    let num = Number(nums[0]);

    for(let i = 1; i <= num; i++)
        console.log(i);
}