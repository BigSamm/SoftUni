function multiplyNumbers(nums) {
    let num1 = Number(nums[0]);
    let num2 = Number(nums[1]);

    return num1 * num2;
}