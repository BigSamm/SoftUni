function multiplyNumber(nums) {
    let num = Number(nums[0]);
    return num * 2;
}