﻿namespace Services.Contracts
{
    public interface IHashService
    {
        string Hash(string stringToHash);
    }
}
