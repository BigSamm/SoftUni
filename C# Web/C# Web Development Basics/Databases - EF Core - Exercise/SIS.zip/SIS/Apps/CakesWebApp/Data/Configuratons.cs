﻿namespace CakesWebApp.Data
{
    public static class Configuratons
    {
        public const string ConnectionString = @"Server=DESKTOP-V2T7ERB\SQLEXPRESS; Database=CakesDb; Integrated Security=True";
    }
}
