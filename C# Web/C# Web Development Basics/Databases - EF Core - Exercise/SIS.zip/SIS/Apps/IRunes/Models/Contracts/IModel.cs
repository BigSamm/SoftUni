﻿namespace IRunes.Models.Contracts
{
    public interface IModel
    {
        string Id { get; }
    }
}
