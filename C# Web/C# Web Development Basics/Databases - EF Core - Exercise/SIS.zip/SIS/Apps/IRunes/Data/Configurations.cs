﻿namespace IRunes.Data
{
    public static class Configurations
    {
        public const string ConnectionString = @"Server=DESKTOP-V2T7ERB\SQLEXPRESS; Database=IRunesDb; Integrated Security=True";
    }
}
