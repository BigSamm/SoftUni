﻿namespace SIS.HTTP.Responses.Contracts
{
    using System.Net;

    using Headers;
    using Headers.Contracts;

    public interface IHttpResponse
    {
        HttpStatusCode StatusCode { get; }

        IHttpHeaderCollection Headers { get; }

        byte[] Content { get; }

        void AddHeader(HttpHeader header);

        byte[] GetBytes();
    }
}
