﻿namespace SIS.Demo
{
    using System.Net;

    using HTTP.Responses.Contracts;
    using WebServer.Results;

    public class HomeController
    {
        public IHttpResponse Index()
        {
            string content = "<h1>Hello World!</h1>";

            return new HtmlResult(content, HttpStatusCode.OK);
        }
    }
}
