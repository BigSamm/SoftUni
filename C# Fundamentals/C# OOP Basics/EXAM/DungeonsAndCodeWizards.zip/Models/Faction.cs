﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DungeonsAndCodeWizards.Models
{
    public enum Faction
    {
        CSharp,
        Java
    }
}
