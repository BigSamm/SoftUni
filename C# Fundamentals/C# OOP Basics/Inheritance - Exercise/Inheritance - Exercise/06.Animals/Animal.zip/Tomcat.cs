﻿using System;
using System.Collections.Generic;
using System.Text;

public class Tomcat : Cat
{
    public Tomcat(string name, int age, string type) 
        : base(name, age, "Male", type)
    {

    }
}
