﻿public interface ISoundProducable
{
    string ISoundProducable();
}
