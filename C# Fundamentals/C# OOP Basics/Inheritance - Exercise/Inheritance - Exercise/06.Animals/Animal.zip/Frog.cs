﻿using System;
using System.Collections.Generic;
using System.Text;

public class Frog : Animal
{
    public Frog(string name, int age, string gender, string type) 
        : base(name, age, gender, type)
    {

    }
}