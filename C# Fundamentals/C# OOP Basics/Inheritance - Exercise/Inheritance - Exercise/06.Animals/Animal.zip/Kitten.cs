﻿using System;
using System.Collections.Generic;
using System.Text;

public class Kitten : Cat
{
    public Kitten(string name, int age, string type) 
        : base(name, age, "Female", type)
    {

    }
}
