﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public enum FoodEnum
{
    Mushrooms = -10,
    Apple = 1,
    Melon = 1,
    Cram = 2,
    Lembas = 3,
    HoneyCake = 5
}
