﻿using System;
using System.Collections.Generic;
using System.Text;

public class Seeds : Food
{
    public Seeds(int quantity) : base(quantity)
    {
    }
}