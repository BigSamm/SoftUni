﻿using System;
using System.Collections.Generic;
using System.Text;

public class Car : IVehicle
{
    public Car(double fuel, double expense)
    {
        this.Fuel = fuel;
        this.Expense = expense + 0.9;
    }

    public double Fuel { get; private set; }
    public double Expense { get; private set; }

    public void Drive(double distance)
    {
        var currentExpense = distance * this.Expense;

        if (currentExpense > this.Fuel)
        {
            Console.WriteLine("Car needs refueling");
            return;
        }

        this.Fuel -= currentExpense;
        Console.WriteLine($"Car travelled {distance} km");
    }

    public void Refuel(double liters)
    {
        this.Fuel += liters;
    }
}