﻿using System;
using System.Collections.Generic;
using System.Text;

public class Truck : IVehicle
{
    public Truck(double fuel, double expense)
    {
        this.Fuel = fuel;
        this.Expense = expense + 1.6;
    }

    public double Fuel { get; private set; }
    public double Expense { get; private set; }

    public void Drive(double distance)
    {
        var currentExpense = distance * this.Expense;

        if (currentExpense > this.Fuel)
        {
            Console.WriteLine("Truck needs refueling");
            return;
        }

        this.Fuel -= currentExpense;
        Console.WriteLine($"Truck travelled {distance} km");
    }

    public void Refuel(double liters)
    {
        this.Fuel += liters * 0.95;
    }
}