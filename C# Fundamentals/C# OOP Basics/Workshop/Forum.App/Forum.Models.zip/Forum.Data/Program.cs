﻿using Forum.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Forum.Data
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
