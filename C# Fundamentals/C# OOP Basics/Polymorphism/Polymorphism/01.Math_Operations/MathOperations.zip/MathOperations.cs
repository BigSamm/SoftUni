﻿using System;
using System.Collections.Generic;
using System.Text;

public class MathOperations
{
    public int Add(int num1, int num2)
    {
        var result = num1 + num2;
        return result;
    }

    public double Add(double num1, double num2, double num3)
    {
        var result = num1 + num2 + num3;
        return result;
    }

    public decimal Add(decimal num1, decimal num2, decimal num3)
    {
        var result = num1 + num2 + num3;
        return result;
    }
}