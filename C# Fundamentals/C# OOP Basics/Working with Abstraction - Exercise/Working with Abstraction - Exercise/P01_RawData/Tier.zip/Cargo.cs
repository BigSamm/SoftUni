﻿using System;
using System.Collections.Generic;
using System.Text;

public class Cargo
{
    public int Weight;
    public string Type;

    public Cargo(int weight, string type)
    {
        Weight = weight;
        Type = type;
    }
}
