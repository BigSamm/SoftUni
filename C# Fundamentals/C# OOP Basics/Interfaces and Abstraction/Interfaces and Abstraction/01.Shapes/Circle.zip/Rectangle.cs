﻿using System;
using System.Collections.Generic;
using System.Text;

public class Rectangle : IDrawable
{
    public int Width { get; private set; }
    public int Height { get; private set; }

    public Rectangle(int width, int height)
    {
        Width = width;
        Height = height;
    }

    public void Draw()
    {
        DrawFirstAndLastLines();

        for (int i = 1; i < Height; i++)
        {
            DrawMiddle();
        }

        DrawFirstAndLastLines();
    }

    private void DrawMiddle()
    {
        Console.Write('*');
        Console.Write(new string(' ', Width - 2));
        Console.WriteLine('*');
    }

    private void DrawFirstAndLastLines()
    {
        Console.WriteLine(new string('*', Width));
    }
}