﻿using System;
using System.Collections.Generic;
using System.Text;

public class Circle : IDrawable
{
    public int Radius { get; private set; }

    public Circle(int radius)
    {
        Radius = radius;
    }

    public void Draw()
    {
        DrawFirstAndLastLine();

        var middleCount = Radius * 2 + 1;
        for (int row = 1; row < Radius; row++)
        {
            DrawFirstAndSecondHalf(row, middleCount);
            middleCount += 2;
        }

        DrawMiddle();

        middleCount = Radius * 3;
        for (int row = Radius - 1; row > 0; row--)
        {
            DrawFirstAndSecondHalf(row, middleCount);
            middleCount -= 2;
        }

        DrawFirstAndLastLine();
    }

    private void DrawMiddle()
    {
        Console.Write('*');
        Console.Write(new string(' ', Radius * 4 - 1));
        Console.WriteLine('*');
    }

    private void DrawFirstAndSecondHalf(int row, int middleCount)
    {
        var startCount = Radius - row * 2;
        if (startCount < 0)
            startCount = 0;

        Console.Write(new string(' ', startCount));
        Console.Write("**");
        
        Console.Write(new string(' ', middleCount));
        Console.WriteLine("**");
    }

    private void DrawFirstAndLastLine()
    {
        Console.Write(new string(' ', Radius));
        Console.WriteLine(new string('*', Radius * 2 + 1));
    }
}