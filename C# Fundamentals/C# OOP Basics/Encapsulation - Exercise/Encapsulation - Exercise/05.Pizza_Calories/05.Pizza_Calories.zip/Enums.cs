﻿public enum FlourTypeEnum
{
    wholegrain = 10,
    white = 15
}

public enum BakingTechniqueEnum
{
    crispy = 9,
    homemade = 10,
    chewy = 11
}

public enum ToppingTypeEnum
{
    veggies = 8,
    sauce = 9,
    cheese = 11,
    meat = 12
}