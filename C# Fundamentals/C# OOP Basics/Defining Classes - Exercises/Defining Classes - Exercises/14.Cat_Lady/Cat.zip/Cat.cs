﻿using System;
using System.Collections.Generic;
using System.Text;

public class Cat
{
    public string Breed { get; set; }
    public string Name { get; set; }
}