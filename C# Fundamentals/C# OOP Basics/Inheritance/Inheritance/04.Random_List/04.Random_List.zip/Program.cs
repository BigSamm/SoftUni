﻿using System;

class Program
{
    static void Main(string[] args)
    {
        var randomList = new RandomList();

        var randomStr = randomList.RandomString();
    }
}
