﻿using System;
using System.Collections.Generic;

namespace GrandPrix
{
    class StartUp
    {
        static void Main(string[] args)
        {
            var engine = new Engine();
            engine.Run();
        }
    }
}
