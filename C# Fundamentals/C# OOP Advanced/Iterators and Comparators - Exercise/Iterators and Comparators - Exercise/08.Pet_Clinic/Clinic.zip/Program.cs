﻿using System;

namespace _08.Pet_Clinic
{
    class Program
    {
        static void Main(string[] args)
        {
            var engine = new Engine();
            engine.Run();
        }
    }
}
