﻿using System;

namespace _03.Scale
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
