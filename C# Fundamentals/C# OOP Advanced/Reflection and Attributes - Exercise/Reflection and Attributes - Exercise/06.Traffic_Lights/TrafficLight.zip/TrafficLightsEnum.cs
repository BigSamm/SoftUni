﻿public enum TrafficLightsEnum
{
    Red,
    Green,
    Yellow
}