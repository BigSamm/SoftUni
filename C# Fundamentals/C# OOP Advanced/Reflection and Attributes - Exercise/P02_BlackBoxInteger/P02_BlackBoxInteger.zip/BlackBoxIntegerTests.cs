﻿namespace P02_BlackBoxInteger
{
    using System;
    using System.Reflection;

    public class BlackBoxIntegerTests
    {
        public static void Main()
        {
            var className = typeof(BlackBoxInteger).FullName;
            var classType = Type.GetType(className);
            var classInstance = Activator.CreateInstance(classType, true);

            string inputLine;
            while((inputLine = Console.ReadLine()) != "END")
            {
                var inputList = inputLine.Split('_');
                var command = inputList[0];
                var num = int.Parse(inputList[1]);

                var currentMethod = classType.GetMethod(command,
                    BindingFlags.Static | BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public);
                currentMethod.Invoke(classInstance, new object[] { num });

                var fieldName = "innerValue";
                var field = classType.GetField(fieldName,
                    BindingFlags.Static | BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public);

                var result = field.GetValue(classInstance);
                Console.WriteLine(result);
            }
        }
    }
}
