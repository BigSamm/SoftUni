﻿namespace Forum.App.Contracts
{
    public interface IButton : ILabel
    {
		bool IsField { get; }
    }
}
