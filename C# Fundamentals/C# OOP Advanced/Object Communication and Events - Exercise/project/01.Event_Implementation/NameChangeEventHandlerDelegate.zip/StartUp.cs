﻿using System;

public class StartUp
{
    static void Main()
    {
        string name;
        while((name = Console.ReadLine()) != "End")
        {
            var dispatcher = new Dispatcher(name);
        }
    }
}
