﻿using System;
using System.Collections.Generic;
using System.Text;
using static NameChangeEventHandlerDelegate;

public class Dispatcher
{
    private event NameChangeEventHandler NameChange; 
    private string name;

    public Dispatcher(string name)
    {
        this.Name = name;
    }

    public string Name
    {
        get { return name; }
        set
        {
            OnNameChange(new NameChangeEventArgs(value));
            name = value;
        }
    }
    
    public void OnNameChange(NameChangeEventArgs args)
    {
        var handler = new Handler();
        handler.OnDispatcherNameChange(NameChange, args);
    }
}