﻿public static class NameChangeEventHandlerDelegate
{
    public delegate void NameChangeEventHandler();
}