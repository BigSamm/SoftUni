﻿namespace Logger.Models.Enums
{
    public enum ErrorLevel
    {
        INFO,
        WARNING,
        ERROR,
        CRITICAL,
        FATAL
    }
}