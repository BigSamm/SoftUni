﻿using System;

namespace _05.Create_Attribute
{
    [SoftUni("Ventsi")]
    class StartUp
    {
        [SoftUni("Gosho")]
        static void Main(string[] args)
        {
        }
    }
}
