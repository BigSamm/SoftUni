﻿using System;

public class CommandExecutor : IExecutor
{
    public void ExecuteCommand(ICommand command)
    {
        throw new NotImplementedException();
    }
}