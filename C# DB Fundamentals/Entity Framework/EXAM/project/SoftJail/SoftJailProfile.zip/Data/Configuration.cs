﻿namespace SoftJail.Data
{
   public static class Configuration
    {
        public static string ConnectionString = @"Server = DESKTOP-V2T7ERB\SQLEXPRESS; Database = SoftJail; Trusted_Connection = True";
    }
}
