﻿namespace P03_SalesDatabase.Data
{
    public static class Configuration
    {
        public const string ConnectionString = @"Server = DESKTOP-V2T7ERB\SQLEXPRESS; Database = Sales; Integrated Security = True";
    }
}
