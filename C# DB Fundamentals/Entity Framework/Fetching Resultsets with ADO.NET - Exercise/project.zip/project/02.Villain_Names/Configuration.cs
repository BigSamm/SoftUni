﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _02.Villain_Names
{
    public class Configuration
    {
        public const string ConnectionString = @"Server = DESKTOP-V2T7ERB\SQLEXPRESS; Database = MinionsDB; Integrated Security = True";
    }
}
