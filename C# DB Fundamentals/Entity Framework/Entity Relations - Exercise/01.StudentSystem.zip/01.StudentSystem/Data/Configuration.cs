﻿namespace P01_StudentSystem.Data
{
    public class Configuration
    {
        public const string ConnectionString = "Server=.;Database=Student System;Integrated Security=True;";
    }
}
