﻿namespace P01_BillsPaymentSystem.Data.Models.Enums
{
    public enum PaymentMethodType
    {
        BankAccount,
        CreditCard
    }
}
