﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TeamBuilder.Data
{
    public class ConnexConfig
    {
        public const string ConnectionString = @"Server=(localDB)\MSSQLLocalDB;Database=TeamBuilder;Integrated security=True;";
    }
}
