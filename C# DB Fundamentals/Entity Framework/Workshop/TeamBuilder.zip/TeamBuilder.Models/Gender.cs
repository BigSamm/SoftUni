﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TeamBuilder.Models
{
    public enum Gender
    {
        Male,
        Female
    }
}
